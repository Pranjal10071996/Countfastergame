(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib._380 = function() {
	this.initialize(img._380);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,127,120);


(lib._381 = function() {
	this.initialize(img._381);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,139,114);


(lib._389 = function() {
	this.initialize(img._389);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.BGinstructions = function() {
	this.initialize(img.BGinstructions);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,800,480);


(lib.Bitmap1 = function() {
	this.initialize(img.Bitmap1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,284,84);


(lib.Bitmap13 = function() {
	this.initialize(img.Bitmap13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,218,199);


(lib.Bitmap14 = function() {
	this.initialize(img.Bitmap14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,454,147);


(lib.Bitmap16 = function() {
	this.initialize(img.Bitmap16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,454,147);


(lib.Bitmap18 = function() {
	this.initialize(img.Bitmap18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,454,147);


(lib.Bitmap2 = function() {
	this.initialize(img.Bitmap2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,105,69);


(lib.Bitmap22 = function() {
	this.initialize(img.Bitmap22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,478,123);


(lib.Bitmap5 = function() {
	this.initialize(img.Bitmap5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,287,82);


(lib.Bitmap714 = function() {
	this.initialize(img.Bitmap714);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2352,2307);


(lib.Bitmap719 = function() {
	this.initialize(img.Bitmap719);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,316,316);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib._389();
	this.instance.parent = this;
	this.instance.setTransform(-57.3,-57.3,0.896,0.896);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.3,-57.3,114.7,114.7);


(lib.Tween36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib._389();
	this.instance.parent = this;
	this.instance.setTransform(-52.1,-52.1,0.814,0.814);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.1,-52.1,104.3,104.3);


(lib.Tween35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap714();
	this.instance.parent = this;
	this.instance.setTransform(-68.2,-66.9,0.058,0.058);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.2,-66.9,136.6,134);


(lib.Tween28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap714();
	this.instance.parent = this;
	this.instance.setTransform(-62.6,-61.4,0.053,0.053);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.6,-61.4,125.2,122.8);


(lib.Symbol77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.scoretext = new cjs.Text("0", "50px 'Tw Cen MT Condensed Extra Bold'", "#FFFFFF");
	this.scoretext.name = "scoretext";
	this.scoretext.lineHeight = 56;
	this.scoretext.parent = this;
	this.scoretext.setTransform(34,12.7);

	this.timeline.addTween(cjs.Tween.get(this.scoretext).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AmHGBQhkAAAAhkIAAo5QAAhkBkAAIMPAAQBkAAAABkIAAI5QAABkhkAAg");
	this.shape.setTransform(49.2,38.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol77, new cjs.Rectangle(0,0,98.5,77.1), null);


(lib.Symbol72copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhiCnIBqi1QATggAAgbQAAgOgGgIQgFgJgJAAQgNAAgEAMQgFAKAAAhIAAAMIhHAAQAAgkADgVQADgVAKgQQAJgQAUgJQAUgKAaAAQAtAAAZAXQAYAYAAAtQAAAXgJAaQgKAagSAfIgoBFIBBAAIAABCg");
	this.shape.setTransform(126.2,36);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("Ag3AfIAAg8IBvAAIAAA8g");
	this.shape_1.setTransform(106.8,41.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_2.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap18();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol72copy5, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol72copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhHCSQgagaAAgsQAAgLABgJQACgJADgJQADgIAEgIQAFgIAGgGQAGgGAJgFIARgKIAAgBIAAAAIgBAAIAAgBQgPgHgJgIQgKgIgHgQQgHgPAAgUQAAgjAagXQAagYAmAAQAnAAAaAYQAZAYAAAlQAAAYgMARQgNASgZANQAcAMAPAYQAPAYAAAeQAAAsgaAaQgbAagtAAQgsAAgbgagAgbBDQAAAuAbAAQAaABAAgsQAAgvgaAAQgbAAAAAsgAgShPQAAASAEAJQAFAHAJAAQASAAAAgfQAAgjgSAAQgSAAAAAgg");
	this.shape.setTransform(111,36.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap18();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol72copy4, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol72copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhBCTQgagZgCgrIBGAAQAAAeAXAAQAXAAAAgpQAAgTgHgHQgGgIgQAAIgXAAIAAhCIAZAAQAOAAAHgIQAGgJAAgSQABgogXAAQgKAAgDAIQgEAIABAVIAAAHIhIAAQAAgcAFgQQAEgPAMgPQALgPASgJQASgJAUAAQAlAAAZAbQAZAbgBApQAAAxglAaQAsAXAAA6QAAAXgKAYQgLAXgWAKQgUAKgcAAQgpAAgbgYg");
	this.shape.setTransform(126.9,36.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("Ag3AfIAAg8IBvAAIAAA8g");
	this.shape_1.setTransform(106.8,41.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_2.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap18();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol72copy3, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol72copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhiCnIBqi1QATggAAgbQAAgOgGgIQgFgJgJAAQgNAAgEAMQgFAKAAAhIAAAMIhHAAQAAgkADgVQADgVAKgQQAJgQAUgJQAUgKAaAAQAtAAAZAXQAYAYAAAtQAAAXgJAaQgKAagSAfIgoBFIBBAAIAABCg");
	this.shape.setTransform(126.2,36);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("Ag3AfIAAg8IBvAAIAAA8g");
	this.shape_1.setTransform(106.8,41.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_2.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap18();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol72copy2, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol72copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhiCnIBqi1QATggAAgbQAAgOgGgIQgFgJgJAAQgNAAgEAMQgFAKAAAhIAAAMIhHAAQAAgkADgVQADgVAKgQQAJgQAUgJQAUgKAaAAQAtAAAZAXQAYAYAAAtQAAAXgJAaQgKAagSAfIgoBFIBBAAIAABCg");
	this.shape.setTransform(110.5,36);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap18();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol72copy, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol70copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AgOCjIAAkBIgpAAIAAhEIBvAAIAAFFg");
	this.shape.setTransform(106.3,36.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap16();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol70copy5, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol70copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhZCZIAKg/QAjAPASAAQAWAAALgPQAMgPAAgaQAAgXgQgNQgPgMgdAAQgNAAgVAFIAXitICKAAIgCBCIhUAAIgGAxQAuACAZAcQAZAaAAAxQAAA1gdAeQgdAfgxABQgbAAgtgPg");
	this.shape.setTransform(107.5,36.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap16();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol70copy4, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol70copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AgzCnIAkhKIAUgyQgQAGgMAAQgkAAgWgcQgWgcAAguQAAgzAdgfQAcgfAuAAQAvAAAdAeQAcAeAAAzQAAATgGAdQgHAbgJAaQgKAZguBggAgXhaQgKANAAATQAAAYAJANQAKAOAOAAQAOAAAJgPQAKgOAAgUQAAgWgJgMQgJgNgOAAQgOAAgKANg");
	this.shape.setTransform(123.5,36);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("Ag3AfIAAg8IBvAAIAAA8g");
	this.shape_1.setTransform(103.5,41.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_2.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap16();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol70copy3, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol70copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhZCZIAKg/QAjAPASAAQAWAAALgPQAMgPAAgaQAAgXgQgNQgPgMgdAAQgNAAgVAFIAXitICKAAIgCBCIhUAAIgGAxQAuACAZAcQAZAaAAAxQAAA1gdAeQgdAfgxABQgbAAgtgPg");
	this.shape.setTransform(123.2,36.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("Ag3AfIAAg8IBvAAIAAA8g");
	this.shape_1.setTransform(103.5,41.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_2.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap16();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol70copy2, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol70copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhZCZIAKg/QAjAPASAAQAWAAALgPQAMgPAAgaQAAgXgQgNQgPgMgdAAQgNAAgVAFIAXitICKAAIgCBCIhUAAIgGAxQAuACAZAcQAZAaAAAxQAAA1gdAeQgdAfgxABQgbAAgtgPg");
	this.shape.setTransform(107.5,36.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap16();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol70copy, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol69copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AAGCjIAAhBIhoAAIAAg1IBgjPIBLAAIAADJIAaAAIAAA7IgaAAIAABBgAgqAnIAwAAIAAhnIgBAAg");
	this.shape.setTransform(112.8,34.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap14();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol69copy5, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol69copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhiCnIBqi1QATggAAgbQAAgOgGgIQgFgJgJAAQgNAAgEAMQgFAKAAAhIAAAMIhHAAQAAgkADgVQADgVAKgQQAJgQAUgJQAUgKAaAAQAtAAAZAXQAYAYAAAtQAAAXgJAaQgKAagSAfIgoBFIBBAAIAABCg");
	this.shape.setTransform(112.2,34.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap14();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol69copy4, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol69copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhKCJQgdgfAAgyQAAg8A4h0IAWgvIBNAAQgqBXgNAkIAJgBIAOgCQAnAAAXAbQAWAZAAAwQAAA0gdAfQgcAggwAAQgtAAgcgfgAgWAXQgKANAAAVQAAAVAJANQAJANAOAAIAAAAQAPAAAKgOQAJgMAAgWQAAgUgKgNQgJgOgPAAQgNAAgJAOg");
	this.shape.setTransform(128.4,35.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("Ag3AfIAAg8IBvAAIAAA8g");
	this.shape_1.setTransform(108.5,39.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_2.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap14();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol69copy3, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol69copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhOCCQgdgpAAhbQAAhQAcgtQAcgrAzAAIAAAAQA1AAAbArQAcAsAABUQAABTgcAsQgcAsg0AAQgwAAgegqgAgkgCQAABoAkAAQATAAAJgYQAIgXAAgyQAAg2gIgaQgJgZgTAAQgkAAAABig");
	this.shape.setTransform(112.6,34.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap14();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol69copy2, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol69copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AhHCSQgagaAAgsQAAgLABgJQACgJADgJQADgIAEgIQAFgIAGgGQAGgGAJgFIARgLIAAAAIAAAAIgBAAIAAgBQgPgHgJgIQgKgIgHgPQgHgQAAgUQAAgjAagXQAagXAmAAQAnAAAaAXQAZAYAAAlQAAAYgMASQgNAQgZAOQAcAMAPAXQAPAZAAAeQAAAsgaAaQgbAagtAAQgsAAgbgagAgbBCQAAAvAbAAQAaABAAgsQAAgvgagBQgbABAAArgAgShPQAAASAEAJQAFAHAJABQASgBAAgfQAAgjgSAAQgSAAAAAgg");
	this.shape.setTransform(112.7,34.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AiMDyQhkAAAAhlIAAkaQAAhjBkAAIEZAAQBkAAAABjIAAEaQAABlhkAAg");
	this.shape_1.setTransform(121,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer 1
	this.instance = new lib.Bitmap14();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol69copy, new cjs.Rectangle(0,0,227,73.5), null);


(lib.Symbol67 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A5pDuIAAnbMAzTAAAIAAHbg");
	this.shape.setTransform(164.2,23.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol67, new cjs.Rectangle(0,0,328.4,47.6), null);


(lib.Symbol60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AhmDCIAAmDIDNAAIAAGDg");
	this.shape.setTransform(10.3,19.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol60, new cjs.Rectangle(0,0,20.6,38.8), null);


(lib.Symbol58copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap13();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.64,0.64);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol58copy, new cjs.Rectangle(0,0,139.5,127.4), null);


(lib.Symbol58 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap13();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.64,0.64);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol58, new cjs.Rectangle(0,0,139.5,127.4), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib._380();
	this.instance.parent = this;
	this.instance.setTransform(19.7,0,0.813,0.813);

	this.instance_1 = new lib.Bitmap2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,1.3,1.327,1.327);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,139.4,97.6), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib._381();
	this.instance.parent = this;
	this.instance.setTransform(21.1,3,0.829,0.829);

	this.instance_1 = new lib.Bitmap2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.327,1.327);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,139.4,97.5), null);


(lib.Symbol76copy6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
		/*currentStep.wrongans.visible = false;
		currentStep.Option1.mouseEnabled = true;
		currentStep.Option2.mouseEnabled = true;
		currentStep.Option3.mouseEnabled = true;
		currentStep.bar.gotoAndPlay(1);*/
		currentStep.wrongans.visible = false;
		currentLevel = 3;
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(1));

	// Layer 1
	this.instance = new lib.Tween36("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(52.1,52.1);

	this.instance_1 = new lib.Tween37("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.1,52.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},16).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},16).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,104.3,104.3);


(lib.Symbol76copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
		/*currentStep.wrongans.visible = false;
		currentStep.Option1.mouseEnabled = true;
		currentStep.Option2.mouseEnabled = true;
		currentStep.Option3.mouseEnabled = true;
		currentStep.bar.gotoAndPlay(1);*/
		currentStep.wrongans.visible = false;
		currentLevel = 2;
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(1));

	// Layer 1
	this.instance = new lib.Tween36("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(52.1,52.1);

	this.instance_1 = new lib.Tween37("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.1,52.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},16).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},16).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,104.3,104.3);


(lib.Symbol76copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
		/*currentStep.wrongans.visible = false;
		currentStep.Option1.mouseEnabled = true;
		currentStep.Option2.mouseEnabled = true;
		currentStep.Option3.mouseEnabled = true;
		currentStep.bar.gotoAndPlay(1);*/
		currentStep.wrongans.visible = false;
		createWinScreen();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(1));

	// Layer 1
	this.instance = new lib.Tween36("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(52.1,52.1);

	this.instance_1 = new lib.Tween37("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.1,52.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},16).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},16).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,104.3,104.3);


(lib.Symbol76copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
		/*currentStep.wrongans.visible = false;
		currentStep.Option1.mouseEnabled = true;
		currentStep.Option2.mouseEnabled = true;
		currentStep.Option3.mouseEnabled = true;
		currentStep.bar.gotoAndPlay(1);*/
		currentStep.wrongans.visible = false;
		currentLevel = 5;
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(1));

	// Layer 1
	this.instance = new lib.Tween36("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(52.1,52.1);

	this.instance_1 = new lib.Tween37("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.1,52.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},16).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},16).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,104.3,104.3);


(lib.Symbol76copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
		/*currentStep.wrongans.visible = false;
		currentStep.Option1.mouseEnabled = true;
		currentStep.Option2.mouseEnabled = true;
		currentStep.Option3.mouseEnabled = true;
		currentStep.bar.gotoAndPlay(1);*/
		currentStep.wrongans.visible = false;
		currentLevel = 4;
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(1));

	// Layer 1
	this.instance = new lib.Tween36("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(52.1,52.1);

	this.instance_1 = new lib.Tween37("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.1,52.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},16).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},16).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,104.3,104.3);


(lib.Symbol73copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
		currentStep.wrongans.visible = false;
		/*currentLevel = 2;
		startGame();*/
		createWinScreen();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(1));

	// Layer 1
	this.instance = new lib.Tween28("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(56.9,55.8);

	this.instance_1 = new lib.Tween35("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(56.9,55.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},12).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},12).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.7,-5.6,125.2,122.8);


(lib.Symbol73copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
		currentStep.rightans.visible = false;
		currentLevel = 5;
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(1));

	// Layer 1
	this.instance = new lib.Tween28("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(56.9,55.8);

	this.instance_1 = new lib.Tween35("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(56.9,55.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},12).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},12).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.7,-5.6,125.2,122.8);


(lib.Symbol73copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
		currentStep.rightans.visible = false;
		currentLevel = 4;
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(1));

	// Layer 1
	this.instance = new lib.Tween28("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(56.9,55.8);

	this.instance_1 = new lib.Tween35("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(56.9,55.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},12).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},12).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.7,-5.6,125.2,122.8);


(lib.Symbol73copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
		currentStep.rightans.visible = false;
		currentLevel = 3;
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(1));

	// Layer 1
	this.instance = new lib.Tween28("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(56.9,55.8);

	this.instance_1 = new lib.Tween35("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(56.9,55.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},12).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},12).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.7,-5.6,125.2,122.8);


(lib.Symbol73copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
		currentStep.rightans.visible = false;
		currentLevel = 2;
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(1));

	// Layer 1
	this.instance = new lib.Tween28("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(56.9,55.8);

	this.instance_1 = new lib.Tween35("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(56.9,55.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},12).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},12).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.7,-5.6,125.2,122.8);


(lib.Symbol59copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_145 = function() {
		this.stop();
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(145).call(this.frame_145).wait(1));

	// Layer 4
	this.instance = new lib.Symbol60();
	this.instance.parent = this;
	this.instance.setTransform(171.5,24,15.909,1,0,0,0,10.7,19.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.07,x:154.8},118).to({regX:10.2,scaleX:0.01,x:153.6},27).wait(1));

	// Layer 1
	this.instance_1 = new lib.Symbol67();
	this.instance_1.parent = this;
	this.instance_1.setTransform(164.2,23.8,1,1,0,0,0,164.2,23.8);
	this.instance_1.alpha = 0.391;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(146));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,329,47.6);


(lib.Symbol59 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_145 = function() {
		this.stop();
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(145).call(this.frame_145).wait(1));

	// Layer 4
	this.instance = new lib.Symbol60();
	this.instance.parent = this;
	this.instance.setTransform(171.5,24,15.909,1,0,0,0,10.7,19.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.07,x:154.8},104).to({regX:10.2,scaleX:0.01,x:153.6},41).wait(1));

	// Layer 1
	this.instance_1 = new lib.Symbol67();
	this.instance_1.parent = this;
	this.instance_1.setTransform(164.2,23.8,1,1,0,0,0,164.2,23.8);
	this.instance_1.alpha = 0.391;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(146));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,329,47.6);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.mouseChildren = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 2
	this.s1 = new lib.Symbol4();
	this.s1.parent = this;
	this.s1.setTransform(69.7,47.5,1,1,0,0,0,69.7,48.8);

	this.timeline.addTween(cjs.Tween.get(this.s1).wait(1));

	// Layer 1
	this.s2 = new lib.Symbol3();
	this.s2.parent = this;
	this.s2.setTransform(69.7,48.8,1,1,0,0,0,69.7,48.8);

	this.timeline.addTween(cjs.Tween.get(this.s2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,-1.3,139.4,98.8), null);


(lib.question5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 8
	this.scorebox = new lib.Symbol77();
	this.scorebox.parent = this;
	this.scorebox.setTransform(55,47.1,1,1,0,0,0,49.2,38.5);

	this.timeline.addTween(cjs.Tween.get(this.scorebox).wait(1));

	// Layer 7
	this.wrongans = new lib.Symbol76copy4();
	this.wrongans.parent = this;
	this.wrongans.setTransform(667.4,158.8,1,1,0,0,0,52.1,52.1);

	this.rightans = new lib.Symbol73copy5();
	this.rightans.parent = this;
	this.rightans.setTransform(677.4,152.3,1,1,0,0,0,56.9,55.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AgHg/IAPAAQAaAAASATQATATAAAZQAAAagTASQgSATgaAAIgPAAQgaAAgTgTQgSgSAAgaQAAgZASgTQATgTAaAAg");
	this.shape.setTransform(935.9,202.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.rightans},{t:this.wrongans}]}).wait(1));

	// Layer 6
	this.Option3 = new lib.Symbol72copy5();
	this.Option3.parent = this;
	this.Option3.setTransform(405.5,438.2,1,1,0,0,0,113.5,36.8);

	this.Option2 = new lib.Symbol70copy5();
	this.Option2.parent = this;
	this.Option2.setTransform(404.7,347.8,1,1,0,0,0,113.5,36.8);

	this.Option1 = new lib.Symbol69copy5();
	this.Option1.parent = this;
	this.Option1.setTransform(403.9,256.8,1,1,0,0,0,113.5,36.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Option1},{t:this.Option2},{t:this.Option3}]}).wait(1));

	// Layer 4
	this.bar = new lib.Symbol59();
	this.bar.parent = this;
	this.bar.setTransform(397.4,164.3,1,1,0,0,0,164.2,23.8);
	this.bar.alpha = 0.391;

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdDnQgSgSAAgXQAAgYASgRQARgRAXAAQAaAAAQAQQAQARAAAZQAAAXgRASQgQAQgZAAQgXAAgRgQgAgsBoIAAh3QAngBARgQQARgRAAgqQAAg5gdAAQgfAAgBA8IhvAAQADhQAognQAogoA+AAQBAAAAnApQAmAnAABDQAABkhSArIAAA9g");
	this.shape_1.setTransform(560.2,86.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AjDB6IAAhMIGHAAIAABMgAjDgtIAAhMIGHAAIAABMg");
	this.shape_2.setTransform(501.7,86.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhwC7Qgqg7AAiDQAAh0AohAQApg/BJAAIAAAAQBMAAAoA/QAnA+AAB6QAAB3goBAQgoA/hLAAQhGAAgqg8gAg0gDQAACVA0AAQAbAAANghQAMgiAAhIQAAhPgMgkQgNglgbAAQg0ABAACNg");
	this.shape_3.setTransform(442.4,86.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUDrIAAlyIg8AAIAAhjIChAAIAAHVg");
	this.shape_4.setTransform(405.1,86.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhQAsIAAhXIChAAIAABXg");
	this.shape_5.setTransform(378.6,94.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AiADcIAOhaQAzAUAZAAQAgAAAQgUQARgVAAgnQAAghgXgSQgVgSgrAAQgTAAgeAHIAij4IDHAAIgCBeIh5AAIgKBHQBDACAkAoQAjAnAABFQAABMgqAtQgpAthGAAQgoAAhAgVg");
	this.shape_6.setTransform(349.1,87.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AglDDIAAidIieAAIAAhLICeAAIAAidIBKAAIAACdICfAAIAABLIifAAIAACdg");
	this.shape_7.setTransform(307.7,86.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhsDFQgpgtAAhIQAAhXBRimIAghDIBvAAQg8B8gVA1IAPgDQAMgCAIAAQA5AAAgAmQAgAlAABFQAABMgqAsQgpAthFAAQhBAAgpgsgAghAgQgNAUAAAfQAAAdANATQAMASAVAAIAAAAQAWAAAOgTQANgTAAgeQAAgdgOgUQgOgUgUAAQgUAAgOAUg");
	this.shape_8.setTransform(266.2,87.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer 3
	this.instance = new lib.BGinstructions();
	this.instance.parent = this;
	this.instance.setTransform(-12.1,-7.2,1.03,1.03);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.question5, new cjs.Rectangle(-12.1,-7.2,956.1,494.4), null);


(lib.question4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 8
	this.scorebox = new lib.Symbol77();
	this.scorebox.parent = this;
	this.scorebox.setTransform(55,47.1,1,1,0,0,0,49.2,38.5);

	this.timeline.addTween(cjs.Tween.get(this.scorebox).wait(1));

	// Layer 7
	this.wrongans = new lib.Symbol76copy3();
	this.wrongans.parent = this;
	this.wrongans.setTransform(667.4,158.8,1,1,0,0,0,52.1,52.1);

	this.rightans = new lib.Symbol73copy4();
	this.rightans.parent = this;
	this.rightans.setTransform(677.4,152.3,1,1,0,0,0,56.9,55.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AgHg/IAPAAQAaAAASATQATATAAAZQAAAagTASQgSATgaAAIgPAAQgaAAgTgTQgSgSAAgaQAAgZASgTQATgTAaAAg");
	this.shape.setTransform(935.9,202.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.rightans},{t:this.wrongans}]}).wait(1));

	// Layer 6
	this.Option3 = new lib.Symbol72copy4();
	this.Option3.parent = this;
	this.Option3.setTransform(405.5,438.2,1,1,0,0,0,113.5,36.8);

	this.Option2 = new lib.Symbol70copy4();
	this.Option2.parent = this;
	this.Option2.setTransform(404.7,347.8,1,1,0,0,0,113.5,36.8);

	this.Option1 = new lib.Symbol69copy4();
	this.Option1.parent = this;
	this.Option1.setTransform(403.9,256.8,1,1,0,0,0,113.5,36.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Option1},{t:this.Option2},{t:this.Option3}]}).wait(1));

	// Layer 4
	this.bar = new lib.Symbol59();
	this.bar.parent = this;
	this.bar.setTransform(397.4,164.3,1,1,0,0,0,164.2,23.8);
	this.bar.alpha = 0.391;

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdDnQgRgSAAgXQAAgYARgRQARgRAXAAQAaAAAQAQQARARAAAZQgBAXgQASQgRAQgZAAQgXAAgRgQgAgsBoIAAh3QAngBARgQQARgRAAgqQAAg5gdAAQgfAAgBA8IhvAAQADhQApgnQAogoA8AAQBBAAAnApQAnAnAABDQgBBkhRArIAAA9g");
	this.shape_1.setTransform(595.4,86.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AjDB6IAAhMIGHAAIAABMgAjDgtIAAhMIGHAAIAABMg");
	this.shape_2.setTransform(537,86.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhwC7Qgqg7AAiDQAAh0AohAQApg/BJAAIAAAAQBMAAAoA/QAnA+AAB6QAAB3goBAQgoA/hLAAQhGAAgqg8gAg0gDQAACVA0AAQAbAAANghQAMgiAAhIQAAhPgMgkQgNglgbAAQg0ABAACNg");
	this.shape_3.setTransform(477.7,86.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUDrIAAlyIg8AAIAAhjIChAAIAAHVg");
	this.shape_4.setTransform(440.4,86.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhQAsIAAhXIChAAIAABXg");
	this.shape_5.setTransform(413.9,94.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhwC7Qgqg7AAiDQAAh0AohAQApg/BJAAIAAAAQBMAAAoA/QAnA+AAB6QAAB3goBAQgoA/hLAAQhGAAgqg8gAg0gDQAACVA0AAQAbAAANghQAMgiAAhIQAAhPgMgkQgNglgbAAQg0ABAACNg");
	this.shape_6.setTransform(384.6,86.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgUDrIAAlyIg8AAIAAhjIChAAIAAHVg");
	this.shape_7.setTransform(347.3,86.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AglDDIAAidIieAAIAAhLICeAAIAAidIBKAAIAACdICfAAIAABLIifAAIAACdg");
	this.shape_8.setTransform(307.7,86.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AiADcIAOhaQAzAUAZAAQAgAAAQgUQARgVAAgnQAAghgXgSQgVgSgrAAQgTAAgeAHIAij4IDHAAIgCBeIh5AAIgKBHQBDACAkAoQAjAnAABFQAABMgqAtQgpAthGAAQgoAAhAgVg");
	this.shape_9.setTransform(265.8,87.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer 3
	this.instance = new lib.BGinstructions();
	this.instance.parent = this;
	this.instance.setTransform(-12.1,-7.2,1.03,1.03);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.question4, new cjs.Rectangle(-12.1,-7.2,956.1,494.4), null);


(lib.question3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 8
	this.scorebox = new lib.Symbol77();
	this.scorebox.parent = this;
	this.scorebox.setTransform(55,47.1,1,1,0,0,0,49.2,38.5);

	this.timeline.addTween(cjs.Tween.get(this.scorebox).wait(1));

	// Layer 7
	this.wrongans = new lib.Symbol76copy2();
	this.wrongans.parent = this;
	this.wrongans.setTransform(667.4,158.8,1,1,0,0,0,52.1,52.1);

	this.rightans = new lib.Symbol73copy3();
	this.rightans.parent = this;
	this.rightans.setTransform(677.4,152.3,1,1,0,0,0,56.9,55.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AgHg/IAPAAQAaAAASATQATATAAAZQAAAagTASQgSATgaAAIgPAAQgaAAgTgTQgSgSAAgaQAAgZASgTQATgTAaAAg");
	this.shape.setTransform(935.9,202.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.rightans},{t:this.wrongans}]}).wait(1));

	// Layer 6
	this.Option3 = new lib.Symbol72copy3();
	this.Option3.parent = this;
	this.Option3.setTransform(405.5,438.2,1,1,0,0,0,113.5,36.8);

	this.Option2 = new lib.Symbol70copy3();
	this.Option2.parent = this;
	this.Option2.setTransform(404.7,347.8,1,1,0,0,0,113.5,36.8);

	this.Option1 = new lib.Symbol69copy3();
	this.Option1.parent = this;
	this.Option1.setTransform(403.9,256.8,1,1,0,0,0,113.5,36.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Option1},{t:this.Option2},{t:this.Option3}]}).wait(1));

	// Layer 4
	this.bar = new lib.Symbol59();
	this.bar.parent = this;
	this.bar.setTransform(397.4,164.3,1,1,0,0,0,164.2,23.8);
	this.bar.alpha = 0.391;

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdDnQgRgSAAgXQAAgYARgRQARgRAXAAQAZAAARAQQARARAAAZQgBAXgRASQgQAQgZAAQgXAAgRgQgAgsBoIAAh3QAngBARgQQARgRAAgqQAAg5gdAAQgfAAgBA8IhvAAQADhQAognQApgoA8AAQBBAAAnApQAmAnAABDQAABkhSArIAAA9g");
	this.shape_1.setTransform(524.9,86.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AjCB6IAAhMIGGAAIAABMgAjCgtIAAhMIGGAAIAABMg");
	this.shape_2.setTransform(466.5,86.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhmDSQgmglAAg/QAAgQACgOQACgOAFgLQADgNAIgKQAGgLAJgJQAJgKAMgGIAZgQIAAgBIAAAAIgBgBIgBAAQgVgKgNgMQgPgMgJgVQgLgXABgdQAAgyAlghQAlgiA3AAQA5AAAkAiQAlAiAAA2QAAAigSAZQgRAZglATQAoARAWAjQAWAjgBAsQABA/gmAlQgnAlhBAAQhAAAgmglgAgnBfQAABEAnAAQAmAAAAg9QAAhFgmgBQgnAAAAA/gAgbhzQAAAcAHALQAGALAOAAQAaABAAguQAAgzgaABQgbAAAAAtg");
	this.shape_3.setTransform(407.2,86.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhQAsIAAhXIChAAIAABXg");
	this.shape_4.setTransform(378.6,94.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgUDrIAAlyIg8AAIAAhjIChAAIAAHVg");
	this.shape_5.setTransform(347.3,86.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AglDDIAAidIieAAIAAhLICeAAIAAidIBKAAIAACdICfAAIAABLIifAAIAACdg");
	this.shape_6.setTransform(307.7,86.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgUDrIAAlyIg8AAIAAhjIChAAIAAHVg");
	this.shape_7.setTransform(264,86.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer 3
	this.instance = new lib.BGinstructions();
	this.instance.parent = this;
	this.instance.setTransform(-12.1,-7.2,1.03,1.03);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.question3, new cjs.Rectangle(-12.1,-7.2,956.1,494.4), null);


(lib.question2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 8
	this.scorebox = new lib.Symbol77();
	this.scorebox.parent = this;
	this.scorebox.setTransform(55,47.1,1,1,0,0,0,49.2,38.5);

	this.timeline.addTween(cjs.Tween.get(this.scorebox).wait(1));

	// Layer 7
	this.wrongans = new lib.Symbol76copy6();
	this.wrongans.parent = this;
	this.wrongans.setTransform(667.4,158.8,1,1,0,0,0,52.1,52.1);

	this.rightans = new lib.Symbol73copy2();
	this.rightans.parent = this;
	this.rightans.setTransform(677.4,152.3,1,1,0,0,0,56.9,55.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AgHg/IAPAAQAaAAASATQATATAAAZQAAAagTASQgSATgaAAIgPAAQgaAAgTgTQgSgSAAgaQAAgZASgTQATgTAaAAg");
	this.shape.setTransform(935.9,202.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.rightans},{t:this.wrongans}]}).wait(1));

	// Layer 6
	this.Option3 = new lib.Symbol72copy2();
	this.Option3.parent = this;
	this.Option3.setTransform(405.5,438.2,1,1,0,0,0,113.5,36.8);

	this.Option2 = new lib.Symbol70copy2();
	this.Option2.parent = this;
	this.Option2.setTransform(404.7,347.8,1,1,0,0,0,113.5,36.8);

	this.Option1 = new lib.Symbol69copy2();
	this.Option1.parent = this;
	this.Option1.setTransform(403.9,256.8,1,1,0,0,0,113.5,36.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Option1},{t:this.Option2},{t:this.Option3}]}).wait(1));

	// Layer 4
	this.bar = new lib.Symbol59();
	this.bar.parent = this;
	this.bar.setTransform(397.4,164.3,1,1,0,0,0,164.2,23.8);
	this.bar.alpha = 0.391;

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdDnQgRgSAAgXQAAgYARgRQARgRAXAAQAZAAARAQQARARAAAZQgBAXgRASQgQAQgZAAQgXAAgRgQgAgsBoIAAh3QAngBARgQQARgRAAgqQAAg5gdAAQgfAAgBA8IhvAAQADhQAognQApgoA8AAQBBAAAnApQAmAnAABDQAABkhSArIAAA9g");
	this.shape_1.setTransform(524.9,86.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AjCB6IAAhMIGGAAIAABMgAjCgtIAAhMIGGAAIAABMg");
	this.shape_2.setTransform(466.5,86.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AiADcIAOhaQAzAUAZAAQAgAAAQgUQARgVAAgnQAAghgXgSQgVgSgrAAQgTAAgeAHIAij4IDHAAIgCBeIh5AAIgKBHQBDACAkAoQAjAnAABFQAABMgqAtQgpAthGAAQgoAAhAgVg");
	this.shape_3.setTransform(406.9,87.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhQAsIAAhXIChAAIAABXg");
	this.shape_4.setTransform(378.6,94.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgUDrIAAlyIg8AAIAAhjIChAAIAAHVg");
	this.shape_5.setTransform(347.3,86.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AglDDIAAidIieAAIAAhLICeAAIAAidIBKAAIAACdICfAAIAABLIifAAIAACdg");
	this.shape_6.setTransform(307.7,86.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AiNDxICYkFQAcgvAAgnQAAgTgIgNQgJgMgMAAQgTAAgGAQQgHAQAAAvIAAARIhnAAQAAg0AFgeQAEgeAOgXQAOgXAdgOQAcgOAmAAQBBAAAjAiQAjAiAABBQAAAhgNAmQgOAlgaAuIg6BiIBfAAIAABgg");
	this.shape_7.setTransform(265.4,86.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer 3
	this.instance = new lib.BGinstructions();
	this.instance.parent = this;
	this.instance.setTransform(-12.1,-7.2,1.03,1.03);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.question2, new cjs.Rectangle(-12.1,-7.2,956.1,494.4), null);


(lib.question1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 8
	this.scorebox = new lib.Symbol77();
	this.scorebox.parent = this;
	this.scorebox.setTransform(55,47.1,1,1,0,0,0,49.2,38.5);

	this.timeline.addTween(cjs.Tween.get(this.scorebox).wait(1));

	// Layer 7
	this.wrongans = new lib.Symbol76copy5();
	this.wrongans.parent = this;
	this.wrongans.setTransform(667.4,158.8,1,1,0,0,0,52.1,52.1);

	this.rightans = new lib.Symbol73copy();
	this.rightans.parent = this;
	this.rightans.setTransform(677.4,152.3,1,1,0,0,0,56.9,55.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AgHg/IAPAAQAaAAASATQATATAAAZQAAAagTASQgSATgaAAIgPAAQgaAAgTgTQgSgSAAgaQAAgZASgTQATgTAaAAg");
	this.shape.setTransform(935.9,202.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.rightans},{t:this.wrongans}]}).wait(1));

	// Layer 6
	this.Option3 = new lib.Symbol72copy();
	this.Option3.parent = this;
	this.Option3.setTransform(405.5,438.2,1,1,0,0,0,113.5,36.8);

	this.Option2 = new lib.Symbol70copy();
	this.Option2.parent = this;
	this.Option2.setTransform(404.7,347.8,1,1,0,0,0,113.5,36.8);

	this.Option1 = new lib.Symbol69copy();
	this.Option1.parent = this;
	this.Option1.setTransform(403.9,256.8,1,1,0,0,0,113.5,36.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Option1},{t:this.Option2},{t:this.Option3}]}).wait(1));

	// Layer 4
	this.bar = new lib.Symbol59copy();
	this.bar.parent = this;
	this.bar.setTransform(397.4,164.3,1,1,0,0,0,164.2,23.8);
	this.bar.alpha = 0.391;

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdDnQgRgSAAgXQAAgYARgRQARgRAXAAQAZAAARAQQARARAAAZQgBAXgRASQgQAQgZAAQgXAAgRgQgAgsBoIAAh3QAngBARgQQARgRAAgqQAAg5gdAAQgfAAgBA8IhvAAQADhQAognQApgoA8AAQBBAAAnApQAmAnAABDQAABkhSArIAAA9g");
	this.shape_1.setTransform(524.9,86.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AjCB6IAAhMIGGAAIAABMgAjCgtIAAhMIGGAAIAABMg");
	this.shape_2.setTransform(466.5,86.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAIDrIAAheIiVAAIAAhMICKkrIBtAAIAAEiIAkAAIAABVIgkAAIAABegAg8A4IBEAAIAAiUIgBAAg");
	this.shape_3.setTransform(407.4,86.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhQAsIAAhXIChAAIAABXg");
	this.shape_4.setTransform(378.6,94.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhmDSQgnglAAg/QAAgQADgOQACgOAEgLQAFgNAHgKQAGgLAJgJQAJgKANgGIAYgQIAAgBIgBAAIAAgBIgBAAQgVgKgOgMQgOgMgJgVQgKgXAAgdQAAgyAlghQAlgiA3AAQA5AAAkAiQAlAiAAA2QgBAigRAZQgSAZgkATQAnARAXAjQAWAjAAAsQgBA/glAlQgnAlhBAAQhAAAgmglgAgmBfQgBBEAnAAQAmAAAAg9QAAhFgmgBQgmAAAAA/gAgbhzQABAcAGALQAHALANAAQAaABAAguQABgzgbABQgaAAgBAtg");
	this.shape_5.setTransform(349.4,86.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AglDDIAAidIieAAIAAhLICeAAIAAidIBKAAIAACdICfAAIAABLIifAAIAACdg");
	this.shape_6.setTransform(307.7,86.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgUDrIAAlyIg8AAIAAhjIChAAIAAHVg");
	this.shape_7.setTransform(264,86.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer 3
	this.instance = new lib.BGinstructions();
	this.instance.parent = this;
	this.instance.setTransform(-12.1,-7.2,1.03,1.03);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.question1, new cjs.Rectangle(-12.1,-7.2,956.1,494.4), null);


(lib.Welcome = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.BtnSound = new lib.Symbol1();
	this.BtnSound.parent = this;
	this.BtnSound.setTransform(725,59.6,1,1,0,0,0,69.7,48.8);

	this.timeline.addTween(cjs.Tween.get(this.BtnSound).wait(1));

	// Layer 9
	this.Btnplay = new lib.Symbol58();
	this.Btnplay.parent = this;
	this.Btnplay.setTransform(418.3,371.1,1,1,0,0,0,69.8,63.6);

	this.timeline.addTween(cjs.Tween.get(this.Btnplay).wait(1));

	// Layer 5
	this.instance = new lib.Bitmap1();
	this.instance.parent = this;
	this.instance.setTransform(342.4,177.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 6
	this.instance_1 = new lib.Bitmap5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(328.7,222.1,0.64,0.64);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer 4
	this.instance_2 = new lib.Bitmap719();
	this.instance_2.parent = this;
	this.instance_2.setTransform(337.2,11.2,0.519,0.519);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer 3
	this.instance_3 = new lib.BGinstructions();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-12.1,-7.2,1.03,1.03);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Welcome, new cjs.Rectangle(-12.1,-7.2,824,494.4), null);


(lib.scorescreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 11
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AgcBbQgMgMAAgQQAAgRAMgMQAMgLAQgBQAQAAAMAMQAMAMAAARQAAAQgMANQgMALgQAAQgQAAgMgMgAgcghQgMgMAAgRQAAgRAMgMQAMgLAQAAQARAAAMAMQAMAMAAARQAAAQgMAMQgMALgRAAQgQABgMgMg");
	this.shape.setTransform(551.6,122.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("AhKCjIAAlFICVAAIAABFIhLAAIAAA9IBAAAIAABCIhAAAIAAA7IBLAAIAABGg");
	this.shape_1.setTransform(522.7,115.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#660000").s().p("AAcCjIg7iVIgBAAIAACVIhKAAIAAlFIBXAAQAzAAAeAbQAfAbgBAuQAAAYgLAWQgLAVgXALIA8CTgAgggWQAxgBAAghQAAgXgMgJQgKgKgbgBg");
	this.shape_2.setTransform(500.4,115.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#660000").s().p("AhYB+QgfgtAAhUQAAhQAfgrQAggsA3gBQA6ABAgAsQAfAsAABSQAABRgfAtQgfAtg5AAQg6AAgfgtgAgogCQAAA7AKAVQAJATAUABQAUgBALgTQALgVAAg6QAAhggqAAQgnABAABeg");
	this.shape_3.setTransform(472.2,115.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#660000").s().p("Ag0B8QgogxAAhNQAAhKApgvQAngwA9AAQAYABAUAGIAABNQgVgGgTAAQgdAAgTAaQgSAaAAApQAAArASAaQAUAZAfAAQAQAAAVgHIAABNQgYAHgSAAQg/AAgogvg");
	this.shape_4.setTransform(447.6,115.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#660000").s().p("AhMCdIAAhMQAjAVAYAAQAOAAAHgIQAIgIAAgMQAAgKgGgJQgGgIgQgMQgmgegRgYQgRgZAAgfQAAgqAagbQAbgbApAAQAfAAAfAOIAABJQghgSgUAAQgOAAgHAGQgIAHAAAMQAAAUAkAaQAWAPAXAbQAWAbAAAkQAAAqgdAcQgeAcgsAAQgfAAgfgPg");
	this.shape_5.setTransform(425.6,115.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#660000").s().p("AglCjIAAj6IgyAAIAAhLICvAAIAABLIgzAAIAAD6g");
	this.shape_6.setTransform(392.2,115.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#660000").s().p("AhMCdIAAhMQAjAVAYAAQAOAAAHgIQAIgIAAgMQAAgKgGgJQgGgIgQgMQgmgegRgYQgRgZAAgfQAAgqAagbQAbgbApAAQAfAAAfAOIAABJQghgSgUAAQgOAAgHAGQgIAHAAAMQAAAUAkAaQAWAPAXAbQAWAbAAAkQAAAqgdAcQgeAcgsAAQgfAAgfgPg");
	this.shape_7.setTransform(371.6,115.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#660000").s().p("AhKCjIAAlFICUAAIAABFIhKAAIAAA9IBAAAIAABCIhAAAIAAA7IBLAAIAABGg");
	this.shape_8.setTransform(350.6,115.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#660000").s().p("AhlCjIAAlFIBLAAQBBAAAcAaQAdAaAAAoQAAAqgpAaQAvATAAA0QAAAqgdAaQgeAagwAAgAgbBkQAbgBAOgIQAOgIAAgTQAAgjgxAAIgGAAgAgbgdQAxgBgBgiQABgUgMgHQgLgIgagBg");
	this.shape_9.setTransform(327.8,115.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 7
	this.instance = new lib.Bitmap22();
	this.instance.parent = this;
	this.instance.setTransform(318.9,243.9,0.429,0.429);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 6
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhZCZIAKg+QAjAOASgBQAWAAALgOQAMgPAAgaQAAgXgQgNQgPgMgdAAQgNAAgVAEIAXirICKAAIgCBBIhUAAIgGAyQAuABAZAcQAZAbAAAvQAAA1gdAgQgdAegxAAQgbAAgtgOg");
	this.shape_10.setTransform(621.2,120.2);

	this.instance_1 = new lib.Bitmap2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(590.5,99,0.64,0.64);

	this.scorebox = new lib.Symbol77();
	this.scorebox.parent = this;
	this.scorebox.setTransform(682.2,47.2,0.814,0.814,0,0,0,49.3,38.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#660000").s().p("AwZDiQgngwABhzIAAlCIB5AAIAAFuQAAAZAOAPQANAPAXAAQAYAAAOgQQANgQAAgcIAAlpIB5AAIAAFUQAABGgSAqQgTArgjATQgkAUhAAAQhfAAgmgxgAgiD6IAAh5QA3AhAmAAQAWAAANgMQANgNAAgUQAAgPgLgOQgKgNgZgUQg9gvgagnQgcgpAAgxQAAhEAqgqQAqgrBDAAQAyAAAxAVIAAB2Qg0geggAAQgXAAgNAMQgMAKAAATQAAAhA6AoQAkAZAkArQAjArAAA6QAABEguAsQgwAshJAAQgwAAgwgYgAKxDJQgxhJABiHQAAh+AxhGQAxhHBaAAQBeAAAzBHQAxBGAACDQAACCgwBJQgyBIhbAAQheAAgzhIgAL+gGQAABhAQAfQAQAhAfAAQAhAAASghQARgfAAheQAAiYhDAAQhAAAAACVgAFiDEQg/hNAAh9QAAh0BAhMQA/hMBjAAQAmAAAhAKIAAB9QgigMgfAAQguAAgeAqQgeAqAABBQAABGAeApQAfAoAzAAQAZAAAigMIAAB8QgmAMgeAAQhmAAhAhNgA3iDJQgxhJAAiHQgBh+AyhGQAyhHBZAAQBeAAAzBHQAyBGAACDQAACCgxBJQgxBIhcAAQheAAgyhIgA2XgGQAABhARAfQARAhAeAAQAhAAASghQARgfAAheQABiYhEAAQhBAAAACVgAdCD9QgSgTAAgaQAAgaASgTQATgTAbAAQAaAAAUASQASATAAAbQAAAagTAUQgTASgaAAQgbAAgTgTgAXuEEIAAoHIDwAAIAABuIh6AAIAABgIBpAAIAABsIhpAAIAABeIB7AAIAABvgAUvEEIhgjtIgCAAIAADtIh2AAIAAoHICKAAQBUAAAwAqQAwAsAABJQAAAmgSAkQgTAhgjASIBfDrgATNgjQBPgCAAg1QAAgkgSgQQgSgPgrgCgAmlEEIhgjtIgCAAIAADtIh2AAIAAoHICKAAQBTAAAxAqQAvAsABBJQgBAmgRAkQgTAhgjASIBeDrgAoHgjQBOgCAAg1QABgkgTgQQgRgPgrgCgA8mEEIAAjrIiKkcICFAAQAsBwAUA9IACAAQAUg/ArhuICIAAIiNEcIAADrgAdDA1QgUgUABgaQgBgaAUgTQASgSAcAAQAbAAASAUQATATAAAZQAAAagTATQgSATgbAAQgbAAgTgTg");
	this.shape_11.setTransform(424.4,46.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AwZDiQgngwAAhzIAAlCIB5AAIAAFuQAAAZAOAPQAOAPAXAAQAYAAAOgQQANgQAAgcIAAlpIB5AAIAAFUQAABGgSAqQgTArgjATQgkAUhAAAQhfAAgmgxgAgiD6IAAh5QA3AhAmAAQAWAAANgMQANgNAAgUQAAgPgLgOQgKgNgZgUQg9gvgagnQgcgoAAgyQAAhEAqgqQAqgrBDAAQAyAAAxAVIAAB2Qg0geghAAQgWAAgNAMQgMAKAAATQAAAhA6AoQAkAZAkArQAkArAAA6QAABEgwAsQgvAshJAAQgxAAgvgYgAKxDJQgxhJAAiHQAAh+AyhGQAxhHBZAAQBfAAAzBHQAxBGAACDQAACCgxBJQgxBIhbAAQhfAAgyhIgAL9gGQAABhARAfQAQAhAeAAQAiAAASghQARgfAAheQAAiYhEAAQhAAAAACVgAFiDEQhAhNAAh9QAAh0BBhMQBAhMBiAAQAmAAAhAKIAAB9QgigMgfAAQguAAgeAqQgeAqAABBQAABGAeApQAfAoAzAAQAZAAAigMIAAB8QgmAMgeAAQhmAAhAhNgA3iDJQgyhJAAiHQAAh+AyhGQAyhHBZAAQBeAAAzBHQAyBGAACDQAACCgyBJQgxBIhbAAQheAAgyhIgA2WgGQAABhAQAfQAQAhAfAAQAhAAASghQARgfAAheQAAiYhEAAQg/AAAACVgAdCD9QgTgTAAgaQAAgaATgTQATgTAaAAQAbAAAUASQASATAAAbQAAAagTAUQgTASgbAAQgaAAgTgTgAXvEEIAAoHIDuAAIAABuIh5AAIAABgIBpAAIAABsIhpAAIAABeIB6AAIAABvgAUvEEIhgjtIgCAAIAADtIh2AAIAAoHICKAAQBTAAAxAqQAwAsAABJQAAAmgSAkQgTAhgiASIBdDrgATNgjQBPgCAAg1QAAgkgSgQQgSgPgrgCgAmmEEIhfjtIgCAAIAADtIh2AAIAAoHICKAAQBTAAAwAqQAwAsAABJQAAAmgSAkQgSAhgjASIBeDrgAoHgjQBOgCAAg1QAAgkgSgQQgSgPgqgCgA8mEEIAAjrIiKkcICFAAQAsBwAUA9IABAAQAUg/ArhuICIAAIiMEcIAADrgAdDA1QgUgUAAgaQAAgaAUgTQASgSAcAAQAaAAATAUQATATAAAZQAAAagTATQgTATgaAAQgbAAgTgTg");
	this.shape_12.setTransform(424.4,41.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.scorebox},{t:this.instance_1},{t:this.shape_10}]}).wait(1));

	// Layer 9
	this.Btnplayagain = new lib.Symbol58copy();
	this.Btnplayagain.parent = this;
	this.Btnplayagain.setTransform(418.3,399.1,1,1,0,0,0,69.8,63.6);

	this.timeline.addTween(cjs.Tween.get(this.Btnplayagain).wait(1));

	// Layer 4
	this.instance_2 = new lib.Bitmap719();
	this.instance_2.parent = this;
	this.instance_2.setTransform(339.2,151.2,0.519,0.519);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer 3
	this.instance_3 = new lib.BGinstructions();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-12.1,-7.2,1.03,1.03);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.scorescreen, new cjs.Rectangle(-12.1,-7.2,824,494.4), null);


// stage content:
(lib.countfaster1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		root = this;
		this.stop();
		showHand = true;
		obj = this;
		var currentScreen;
		var currTouchPos = {
			x: 0,
			y: 0
		};
		var lastTouchPos = {
			x: 0,
			y: 0
		};
		var isMouseDown = false;
		
		var setting_open = false;
		var tween = createjs.Tween;
		var ease = createjs.Ease;
		currentLevel = 1;
		//	var currentLevel = 2;
		//	var currentLevel = 3;
		//	var currentLevel = 4;
		maxLevel = 5;
		var canShow = false;
		
		
		Paused = false;
		isSound = true;
		
		
		
		var t1 = createjs.Tween;
		var t2 = createjs.Tween;
		var ease = createjs.Ease;
		var currentFbPosX = null;
		var currentUTPosX = null;
		var currentFullPosX = null;
		
		var newFbPosX = null;
		var newUTPosX = null;
		var newFullPosX = null;
		step1 = null;
		step2 = null;
		step3 = null;
		step4 = null;
		step5 = null;
		currentStep = null;
		welcome = null;
		win = null;
		dragObject = null;
		TotalScore = 0;
		
		function resetS() {
			currentLevel = 1
			//currentStep = null;
		}
		function resetScore() {
			canShow = false;
			TotalScore = 0;
		}
		
		function stopOtherMusic() {
			stopSound(winMSC);
			stopSound(welcomeMSC);
		
			winMSC = null;
			welcomeMSC = null;
		}
		muteAllSounds = function () {
			createjs.Sound.volume = 0.0001;
		}
		
		function toggleSound() {
			console.log("toggleSound ::: ", isSound);
			if (isSound) {
				createjs.Sound.volume = 0.0001;
				if (welcome) {
					console.log("toggleSound  1 ", welcome.BtnSound.s1.visible, welcome.BtnSound.s2.visible);
					welcome.BtnSound.s1.visible = false;
					welcome.BtnSound.s2.visible = true;
					console.log("toggleSound  1 ", welcome.BtnSound.s1.visible, welcome.BtnSound.s2.visible);
				}
				isSound = false;
			} else {
				createjs.Sound.volume = 1;
				if (welcome) {
					console.log("toggleSound  2 ", welcome.BtnSound.s1.visible, welcome.BtnSound.s2.visible);
					welcome.BtnSound.s1.visible = true;
					welcome.BtnSound.s2.visible = false;
					console.log("toggleSound  2 ", welcome.BtnSound.s1.visible, welcome.BtnSound.s2.visible);
				}
				isSound = true;
			}
			//console.log("toggleSound >>>>>> ", isSound);
		}
		function setSound() {
			console.log("setSound", isSound);
			if (isSound) {
		
				if (welcome) {
					console.log("setSound  1 ", welcome.BtnSound.s1.visible, welcome.BtnSound.s2.visible);
					welcome.BtnSound.s1.visible = true;
					welcome.BtnSound.s2.visible = false;
					console.log("setSound  1 ", welcome.BtnSound.s1.visible, welcome.BtnSound.s2.visible);
				}
				if (!isAdPlaying)
					createjs.Sound.volume = 1;
			} else {
				createjs.Sound.volume = 0.0001;
				if (welcome) {
					console.log("setSound  2 ", welcome.BtnSound.s1.visible, welcome.BtnSound.s2.visible);
					welcome.BtnSound.s1.visible = false;
					welcome.BtnSound.s2.visible = true;
					console.log("setSound  2 ", welcome.BtnSound.s1.visible, welcome.BtnSound.s2.visible);
				}
			}
		}
		
		
		
		createWelcome = function () {
			console.log("wwwwwwwwwwwwwwwwwwww");
			resetScore();
			resetS();
			removeStep();
			removeWinScreen();
		
			if (welcome == null) {
				//changeBg(1);
				welcome = new lib.Welcome();
				root.addChild(welcome);
				currentScreen = welcome;
				console.log("wwwwwwwwww1wwwwwwwwww");
				welcome.Btnplay.name = "Btnplay";
				welcome.Btnplay.mouseEnabled = true;
				welcome.Btnplay.mouseChildren = false;
				welcome.BtnSound.name = "BtnSound";
				welcome.BtnSound.mouseEnabled = true;
				welcome.BtnSound.mouseChildren = false;
		
				welcome.addEventListener("click", onDown_Welcome);
				welcome.addEventListener("tick", onTick_Welcome);
			}
			//	setSound();
		}
		function onTick_Welcome() {
			toogleFullScreenBtn();
			welcome.removeEventListener("tick", onTick_Welcome);
		}
		function removeWelcome() {
			if (welcome != null) {
				welcome.removeEventListener("click", onDown_Welcome);
				root.removeChild(welcome);
				welcome = null;
			}
		}
		function onDown_Welcome(e) {
			var str = e.target.name;
			console.log("onDown_Welcome ::", str);
			switch (str) {
				case "Btnplay":
					welcome.Btnplay.mouseEnabled = false;
					playSound("ClickSound");
					tween.get(welcome.Btnplay)
						.to({
							scaleX: 0.9,
							scaleY: 0.9
						}, 100, ease.linear)
						.to({
							scaleX: 1,
							scaleY: 1
						}, 100, ease.backOut).call(startGame);
					//createLevelInstruction();
					break;
		
				case "BtnSound":
					tween.get(welcome.BtnSound)
						.to({
							scaleX: 0.9,
							scaleY: 0.9
						}, 100, ease.linear)
						.to({
							scaleX: 1,
							scaleY: 1
						}, 100, ease.backOut).call(toggleSound);
					//toggleSound();
					break;
			}
		}
		
		
		function removeStep() {
			if (step1 != null) {
				root.removeChild(step1);
				step1 = null;
			}
			if (step2 != null) {
				root.removeChild(step2);
				step2 = null;
			}
			if (step3 != null) {
				root.removeChild(step3);
				step3 = null;
			}
			if (step4 != null) {
				root.removeChild(step4);
				step4 = null;
			}
			if (step5 != null) {
				root.removeChild(step5);
				step5 = null;
			}
			if (currentStep != null) {
				currentStep.removeEventListener("mousedown", onMouseDown);
				//currentStep.removeEventListener("mouseover", onMouseOver);
				//currentStep.removeEventListener("mouseup", onMouseUp);
			}
			currentStep = null;
		}
		
		createWinScreen = function () {
			removeStep();
			if (win == null) {
				stopOtherMusic();
				winMSC = playSound("WinSound", -1);
				win = new lib.scorescreen();
				root.addChild(win);
				console.log("WIN ADDED >>>>>>>>>>>>>>>>>>");
				currentScreen = win;
				win.scorebox.scoretext.text = TotalScore.toString();
				win.Btnplayagain.name = "Btnplayagain";
				win.Btnplayagain.mouseEnabled = true;
				win.Btnplayagain.mouseChildren = false;
				win.addEventListener("click", onDown_Win);
				win.addEventListener("tick", onTick_Win);
			}
			//setSound();
		}
		function onTick_Win() {
			toogleFullScreenBtn();
			win.removeEventListener("tick", onTick_Win);
		}
		
		
		function removeWinScreen() {
			console.log("WIN REMOVED ::", win != null);
			if (win != null) {
				win.removeEventListener("click", onDown_Win);
				root.removeChild(win);
				console.log("WIN REMOVED <<<<<<<<<<<<<<<<<");
				win = null;
			}
		}
		function onDown_Win(e) {
			var str = e.target.name;
			switch (str) {
				case "Btnplayagain":
					playSound("ClickSound");
					win.Btnplayagain.mouseEnabled = false;
					tween.get(win.Btnplayagain)
						.to({
							scaleX: 0.9,
							scaleY: 0.9
						}, 100, ease.linear)
						.to({
							scaleX: 1,
							scaleY: 1
						}, 100, ease.backOut).call(function () {
							stopOtherMusic();
							welcomeMSC = playSound("WelcomeSound", -1);
		
							createWelcome();
						});
					break;
		
			}
		}
		toogleFullScreenBtn = function () {
			if (isInstantGames) return;
			if (currentScreen != null) {
				if (currentScreen.fullScreenBtn != null) {
					if (detectDevice == "Android") {
						if (fullScreenMode) {
							currentScreen.fullScreenBtn.visible = false;
						} else {
							currentScreen.fullScreenBtn.name = "fullScreenBtn";
							currentScreen.fullScreenBtn.mouseEnabled = true;
							currentScreen.fullScreenBtn.mouseChildern = true;
							currentScreen.fullScreenBtn.visible = true;
						}
					} else if (detectDevice == "IOS") {
						currentScreen.fullScreenBtn.visible = false;
					}
		
					if (!isMobile) {
						if (fullScreenMode) {
							currentScreen.fullScreenBtn.fullScreen1.visible = false;
						} else {
							currentScreen.fullScreenBtn.fullScreen1.visible = true;
						}
					}
				}
			}
		}
		
		callPause = function () {
			console.log("pauseeeee", Paused);
			createjs.Sound.volume = 0.0001;
			if (currentStep == null || Paused || levelupDone) return;
			Paused = true;
			showHand = false;
			showMouse();
			showBlackPatch(2);
		}
		callUnpause = function () {
			if (isSound && !isAdPlaying)
				createjs.Sound.volume = 1;
			Paused = false;
			showHand = true;
		}
		startGame = function () {
			removeWelcome();
			removeStep();
		
			if (currentLevel == 1) {
				createStep1();
			} else if (currentLevel == 2) {
				createStep2();
			} else if (currentLevel == 3) {
				createStep3();
			} else if (currentLevel == 4) {
				createStep4();
			} else if (currentLevel == 5) {
				createStep5();
			}
		
			//setSound();
		
		}
		
		createjs.Touch.enable(stage);
		function createStep1() {
			if (step1 == null) {
				//changeBg(1);
				step1 = new lib.question1();
				root.addChild(step1);
				currentStep = step1;
				currentScreen = step1;
				setInitState();
		
				//step1.BtnSound.name = "BtnSound";
			}
			//	updateHUDtime(totalLeveltime)
		}
		function createStep2() {
			if (step2 == null) {
				//changeBg(2);
				step2 = new lib.question2();
				root.addChild(step2);
				currentStep = step2;
				currentScreen = step2;
				setInitState();
				//step1.BtnSound.name = "BtnSound";
			}
			//updateHUDtime(totalLeveltime)
		}
		function createStep3() {
			if (step3 == null) {
				//changeBg(3);
				step3 = new lib.question3();
				root.addChild(step3);
				currentStep = step3;
				currentScreen = step3;
				setInitState();
				//step1.BtnSound.name = "BtnSound";
			}
			//updateHUDtime(totalLeveltime)
		}
		function createStep4() {
			if (step4 == null) {
				//changeBg(4);
				step4 = new lib.question4();
				root.addChild(step4);
				currentStep = step4;
				currentScreen = step4;
				setInitState();
				//step1.BtnSound.name = "BtnSound";
			}
			//updateHUDtime(totalLeveltime)
		}
		function createStep5() {
			if (step5 == null) {
				//changeBg(4);
				step5 = new lib.question5();
				root.addChild(step5);
				currentStep = step5;
				currentScreen = step5;
				setInitState();
				//step1.BtnSound.name = "BtnSound";
			}
			//updateHUDtime(totalLeveltime)
		}
		
		
		function setInitState() {
			levelupDone = false;
			levelPop = false;
			Paused = false;
			//	currentStep.BtnPause.mouseEnabled = true;
			switch (currentLevel) {
				case 1:
					currentStep.rightans.visible = false;
					currentStep.wrongans.visible = false;
					currentStep.bar.visible = true;
					currentStep.bar.gotoAndPlay(1);
					currentStep.addEventListener("tick", barr);
		
					currentStep.Option1.name = "Option1";
					currentStep.Option1.mouseEnabled = true;
					currentStep.Option1.mouseChildren = false;
		
					currentStep.Option2.name = "Option2";
					currentStep.Option2.mouseEnabled = true;
					currentStep.Option2.mouseChildren = false;
		
					currentStep.Option3.name = "Option3";
					currentStep.Option3.mouseEnabled = true;
					currentStep.Option3.mouseChildren = false;
		
		
					break;
				case 2:
					currentStep.scorebox.scoretext.text = TotalScore.toString();
					currentStep.rightans.visible = false;
					currentStep.wrongans.visible = false;
					currentStep.bar.visible = true;
					currentStep.bar.gotoAndPlay(1);
					currentStep.addEventListener("tick", barr);
		
					currentStep.Option1.name = "Option1";
					currentStep.Option1.mouseEnabled = true;
					currentStep.Option1.mouseChildren = false;
		
					currentStep.Option2.name = "Option2";
					currentStep.Option2.mouseEnabled = true;
					currentStep.Option2.mouseChildren = false;
		
					currentStep.Option3.name = "Option3";
					currentStep.Option3.mouseEnabled = true;
					currentStep.Option3.mouseChildren = false;
					currentStep.addEventListener("tick", setscreen2);
		
		
		
					break;
				case 3:
					currentStep.scorebox.scoretext.text = TotalScore.toString();
					currentStep.rightans.visible = false;
					currentStep.wrongans.visible = false;
					currentStep.bar.visible = true;
					currentStep.bar.gotoAndPlay(1);
					currentStep.addEventListener("tick", barr);
		
					currentStep.Option1.name = "Option1";
					currentStep.Option1.mouseEnabled = true;
					currentStep.Option1.mouseChildren = false;
		
					currentStep.Option2.name = "Option2";
					currentStep.Option2.mouseEnabled = true;
					currentStep.Option2.mouseChildren = false;
		
					currentStep.Option3.name = "Option3";
					currentStep.Option3.mouseEnabled = true;
					currentStep.Option3.mouseChildren = false;
					currentStep.addEventListener("tick", setscreen3);
					break;
		
				case 4:
					currentStep.scorebox.scoretext.text = TotalScore.toString();
					currentStep.rightans.visible = false;
					currentStep.wrongans.visible = false;
					currentStep.bar.visible = true;
					currentStep.bar.gotoAndPlay(1);
					currentStep.addEventListener("tick", barr);
		
					currentStep.Option1.name = "Option1";
					currentStep.Option1.mouseEnabled = true;
					currentStep.Option1.mouseChildren = false;
		
					currentStep.Option2.name = "Option2";
					currentStep.Option2.mouseEnabled = true;
					currentStep.Option2.mouseChildren = false;
		
					currentStep.Option3.name = "Option3";
					currentStep.Option3.mouseEnabled = true;
					currentStep.Option3.mouseChildren = false;
					currentStep.addEventListener("tick", setscreen4);
		
					break;
				case 5:
					currentStep.scorebox.scoretext.text = TotalScore.toString();
					currentStep.rightans.visible = false;
					currentStep.wrongans.visible = false;
					currentStep.bar.visible = true;
					currentStep.bar.gotoAndPlay(1);
					currentStep.addEventListener("tick", barr);
		
					currentStep.Option1.name = "Option1";
					currentStep.Option1.mouseEnabled = true;
					currentStep.Option1.mouseChildren = false;
		
					currentStep.Option2.name = "Option2";
					currentStep.Option2.mouseEnabled = true;
					currentStep.Option2.mouseChildren = false;
		
					currentStep.Option3.name = "Option3";
					currentStep.Option3.mouseEnabled = true;
					currentStep.Option3.mouseChildren = false;
					currentStep.addEventListener("tick", setscreen5);
					break;
			}
			showHand = true;
			canShow = true;
			currentStep.addEventListener("mousedown", onMouseDown);
		}
		function barr() {
		
			currentStep.bar.gotoAndPlay(1);
			currentStep.removeEventListener("tick", barr);
		}
		function setscreen2() {
			currentStep.rightans.visible = false;
			currentStep.wrongans.visible = false;
			currentStep.bar.visible = true;
			currentStep.bar.gotoAndPlay(1);
			currentStep.addEventListener("tick", barr);
			currentStep.removeEventListener("tick", setscreen2);
		}
		
		function setscreen3() {
			currentStep.rightans.visible = false;
			currentStep.wrongans.visible = false;
			currentStep.bar.visible = true;
			currentStep.bar.gotoAndPlay(1);
			currentStep.addEventListener("tick", barr);
			currentStep.removeEventListener("tick", setscreen3);
		}
		
		function setscreen4() {
			currentStep.rightans.visible = false;
			currentStep.wrongans.visible = false;
			currentStep.bar.visible = true;
			currentStep.bar.gotoAndPlay(1);
			currentStep.addEventListener("tick", barr);
			currentStep.removeEventListener("tick", setscreen4);
		}
		function setscreen5() {
			currentStep.rightans.visible = false;
			currentStep.wrongans.visible = false;
			currentStep.bar.visible = true;
			currentStep.bar.gotoAndPlay(1);
			currentStep.addEventListener("tick", barr);
			currentStep.removeEventListener("tick", setscreen5);
		}
		
		
		function onMouseDown(e) {
			dragOffset = new createjs.Point();
			var str = e.target.name;
		
			if (currentLevel == 1) {
				clickActivity(str);
			}
			if (currentLevel == 2) {
				clickActivity2(str);
			}
			if (currentLevel == 3) {
				clickActivity3(str);
			}
			if (currentLevel == 4) {
				clickActivity4(str);
			}
			if (currentLevel == 5) {
				clickActivity5(str);
			}
		
		
		
		}
		
		
		
		function clickActivity(strng) {
			//strng=event.target.name;
			switch (strng) {
				case "Option1":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
		
				case "Option2":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.rightans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.rightans.gotoAndPlay(1);
						TotalScore++;
						currentStep.scorebox.scoretext.text = TotalScore.toString();
		
						currentStep.bar.gotoAndStop(currentStep.bar.currentFrame);
					}
					break;
		
				case "Option3":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
		
			}
		}
		//step1############done#####################
		
		//step2#####################start####################
		
		function clickActivity2(strng) {
			//strng=event.target.name;
			if (dragObject != null)
				return;
			switch (strng) {
				case "Option1":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
		
				case "Option2":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
		
				case "Option3":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.rightans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.rightans.gotoAndPlay(1);
						TotalScore++;
						currentStep.scorebox.scoretext.text = TotalScore.toString();
		
						currentStep.bar.gotoAndStop(currentStep.bar.currentFrame);
					}
		
					break;
			}
		}
		
		//step2#####################end####################
		
		
		//step3#####################start####################
		function clickActivity3(strng) {
			//strng=event.target.name;
			switch (strng) {
				case "Option1":
		
					if (currentStep.bar.currentFrame != 145) {
						currentStep.rightans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.rightans.gotoAndPlay(1);
						TotalScore++;
						currentStep.scorebox.scoretext.text = TotalScore.toString();
		
						currentStep.bar.gotoAndStop(currentStep.bar.currentFrame);
					}
					break;
		
				case "Option2":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
		
				case "Option3":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
			}
		}
		
		//step3#####################################end####################
		
		//step4#######################start###############
		
		function clickActivity4(strng) {
			//strng=event.target.name;
			switch (strng) {
				case "Option1":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
		
				case "Option2":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.rightans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.rightans.gotoAndPlay(1);
						TotalScore++;
						currentStep.scorebox.scoretext.text = TotalScore.toString();
		
						currentStep.bar.gotoAndStop(currentStep.bar.currentFrame);
					}
					break;
		
				case "Option3":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
			}
		}
		
		//step4########################done#####################
		
		//step5#######################start###############
		
		function clickActivity5(strng) {
			//strng=event.target.name;
			switch (strng) {
				case "Option1":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
		
				case "Option2":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.rightans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.rightans.gotoAndPlay(1);
						TotalScore++;
						currentStep.scorebox.scoretext.text = TotalScore.toString();
		
						currentStep.bar.gotoAndStop(currentStep.bar.currentFrame);
					}
					break;
		
				case "Option3":
					if (currentStep.bar.currentFrame != 145) {
						currentStep.wrongans.visible = true;
						currentStep.Option1.mouseEnabled = false;
						currentStep.Option2.mouseEnabled = false;
						currentStep.Option3.mouseEnabled = false;
						currentStep.wrongans.gotoAndPlay(1);
					}
					break;
			}
		}
		
		//step5########################done#####################
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;
// library properties:
lib.properties = {
	width: 800,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_380.png?1616695276082", id:"_380"},
		{src:"images/_381.png?1616695276082", id:"_381"},
		{src:"images/_389.png?1616695276082", id:"_389"},
		{src:"images/BGinstructions.png?1616695276082", id:"BGinstructions"},
		{src:"images/Bitmap1.png?1616695276082", id:"Bitmap1"},
		{src:"images/Bitmap13.png?1616695276082", id:"Bitmap13"},
		{src:"images/Bitmap14.png?1616695276082", id:"Bitmap14"},
		{src:"images/Bitmap16.png?1616695276082", id:"Bitmap16"},
		{src:"images/Bitmap18.png?1616695276082", id:"Bitmap18"},
		{src:"images/Bitmap2.png?1616695276083", id:"Bitmap2"},
		{src:"images/Bitmap22.png?1616695276083", id:"Bitmap22"},
		{src:"images/Bitmap5.png?1616695276083", id:"Bitmap5"},
		{src:"images/Bitmap714.png?1616695276083", id:"Bitmap714"},
		{src:"images/Bitmap719.png?1616695276083", id:"Bitmap719"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;